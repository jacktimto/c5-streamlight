#include "H\SC92F837X_C.H"
#include "H\data_type.h"
#include "lib\SensorMethod.h"
#include "H\intrins.h"

BOOL timerflag_1ms = 0;
//BOOL timerflag_10ms = 0;
BOOL streamflag    = 0;
INT32U extouchkeyvalueflag = 0;
INT8U extouchkeyvalue = 0;
INT32U a[]={20000,10000,30000};
INT32U delay_ms = 1000;
INT16U count = 0;
INT16U count1 = 0;
INT8U streamtemp = 0x40;

#define LED1  P13
#define LED2  P12
#define LED3  P11
#define LED4  P24
#define LED5  P21
#define LED6  P05
#define LED7  P20
#define LED8  P25

void IOinit(void);
//void pwminit(void);
void timer0init(void);
void updatedisplay(void);
void changetouchkeyvalue(void);
void func1(void);
void waterledmanage(void);

void main()
{
    IOinit();
    TouchKeyInit();
    while (1)
    {   	
        if(timerflag_1ms==1)
        {
            timerflag_1ms=0;
        
            if(SOCAPI_TouchKeyStatus&0x80)
            {
                SOCAPI_TouchKeyStatus&=0x7f;
                extouchkeyvalueflag = TouchKeyScan();
                changetouchkeyvalue();
				        func1();
                TouchKeyRestart();
            }
				}

            if (++count>=delay_ms)
            {
                count = 0;
                updatedisplay();
                waterledmanage();
            }
            
        
    
    }
    

}

/**********************
 * 定时器0初始化
 * 
 * 
 * 
 * *******************/
void timer0init(void)
{
    TMCON = 0x00;//频率Fsys/12
    TCON  = 0x01;//工作模式1
    TH0   = (65536-1000)/256;
    TL0   = (65536-1000)%256;//(Fsys/12)*N   =10^-6 * 10^3 = 1ms
    TF0   = 0;
    TR0   = 0;
    ET0   = 1;
    TR0   = 1;

}


/************************
 * IO初始化
 * 
 * 
 * **********************/
void IOinit(void)
{
    P0CON = 0xff;
    P0PH  = 0xff;

    P1CON = 0xff;
    P1PH  = 0xff;

    P2CON = 0xff;
    P2PH  = 0xff;

    P0    = 0x00;
    P1    = 0x30;
    P2    = 0x40;

    SC92F8371_NIO_Init();

    EA = 1;
    timer0init();
    //PWM_Init();
}
/**************
 * 定时器0中断
 * 
 * 
 * *****************/

/***************
 * 键值转换
 * 
 * 
 * ***************/
void changetouchkeyvalue(void)
{
    switch (extouchkeyvalueflag)
    {
    case 0x00001000:                                //TK12
        extouchkeyvalue = 1;
        break;
    case 0x00000400:                               //TK10             
        extouchkeyvalue = 2;
        break;
    case 0x00002000:                               // TK13
        extouchkeyvalue = 3;
        break;
    default:
        extouchkeyvalue = 0xff; 
        break;
    }
}

void func1(void)
{
    if (extouchkeyvalue==1)
    {
        streamflag =!streamflag;
        if(streamflag ==0){IOinit();}         //可能其他的参数也要初始化
        if(streamflag&&(extouchkeyvalue!=0xff))
        {
           switch (extouchkeyvalue)
           {
           case 1:
               delay_ms = a[0];
               break;
           case 2:
               delay_ms = a[1];
               break;
           case 3:
               delay_ms = a[2];
               break;
        
           }

        }
    }


}
void updatedisplay(void)
{
    streamtemp = _cror_(streamtemp,1);
		if(streamtemp==0x80){streamtemp=0x40;}

}
void waterledmanage(void)
{
    switch (streamtemp)
    {
    case 0x40:
         LED2=1;
         LED3=0;
         LED4=0;
         LED5=0;
         LED6=0;
         LED7=0;
         LED8=0;
        break;
    case 0x20:
         LED2=0;
         LED3=1;
         LED4=0;
         LED5=0;
         LED6=0;
         LED7=0;
         LED8=0;
         break;
    case 0x10:
         LED2=0;
         LED3=0;
         LED4=1;
         LED5=0;
         LED6=0;
         LED7=0;
         LED8=0;
         break;
    case 0x08:
         LED2=0;
         LED3=0;
         LED4=0;
         LED5=1;
         LED6=0;
         LED7=0;
         LED8=0;
         break;
    case 0x04:
         LED2=0;
         LED3=0;
         LED4=0;
         LED5=0;
         LED6=1;
         LED7=0;
         LED8=0;
         break;
    case 0x02:
         LED2=0;
         LED3=0;
         LED4=0;
         LED5=0;
         LED6=0;
         LED7=1;
         LED8=0;
         break;
    case 0x01:
         LED2=0;
         LED3=0;
         LED4=0;
         LED5=0;
         LED6=0;
         LED7=0;
         LED8=1;
         break;   
    default:
        break;
    }
}
void timer0_interrupt() interrupt 1
{
    TH0 = (65536-1000)/256;
    TL0 = (65536-1000)%256;
    timerflag_1ms = 1;
    
}